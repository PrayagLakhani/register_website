CREATE DATABASE IITI;

USE IITI;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userID VARCHAR(50) NOT NULL,
    mobileNumber VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL
);
select * from users;

CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    courseName VARCHAR(100) NOT NULL,
    description TEXT
);

INSERT INTO courses (courseName, description) VALUES
('Discrete Mathematical Structures', 'Study of mathematical structures that are fundamentally discrete rather than continuous.'),
('Data Structures and Algorithms', 'Fundamentals of data organization and algorithmic techniques.'),
('Operating Systems', 'Introduction to operating systems and their design principles.'),
('Database And Information Systems', 'Concepts and techniques for managing data and information.'),
('Computer Networks', 'Study of networking principles, protocols, and applications.'),
('Logic Design', 'Fundamentals of logic circuits and design principles.'),
('Automata Theory and Logic', 'Theoretical foundation of computation and logic.'),
('Design and Analysis of Algorithms', 'Techniques for designing and analyzing algorithms.'),
('Computer Architecture', 'Understanding the design and architecture of computer systems.'),
('Parallel Computing', 'Principles and techniques of parallel computing architectures.'),
('Optimization Algorithms and Techniques', 'Methods for optimizing solutions in various fields.'),
('Computer Graphics and Visualization', 'Techniques for computer graphics and data visualization.'),
('Software Engineering', 'Principles and methodologies for software development.'),
('Compiler Techniques', 'Study of compiler design and implementation.'),
('UX/UI Design', 'Principles of user experience and user interface design.'),
('Matrix Factorization and Applications', 'Methods and applications of matrix factorization.'),
('Mathematics for AI and ML', 'Mathematical foundations for artificial intelligence and machine learning.'),
('Foundation of Algebraic Graph Theory', 'Study of graphs and their algebraic properties.'),
('Foundations of Hardware Security', 'Principles of security in hardware systems.'),
('Introduction to Blockchain', 'Basics of blockchain technology and its applications.'),
('Introduction to Complexity Theory', 'Study of computational complexity and its implications.'),
('Introduction to Internet of Things', 'Principles and applications of IoT systems.'),
('Foundations of Cryptography', 'Basic concepts and techniques in cryptography.'),
('Introduction to Big Data Analysis', 'Techniques and tools for analyzing big data.'),
('Foundations of Secure Computation', 'Principles of secure computation and its applications.'),
('Computer and Network Security', 'Study of security principles in computer and network systems.'),
('Soft Computing', 'Methods and applications of soft computing techniques.'),
('Machine Learning', 'Fundamentals of machine learning algorithms and their applications.');

